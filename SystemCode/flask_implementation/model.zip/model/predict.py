import numpy as np
import cv2
import tensorflow as tf
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import Model  
from model.integrated_model import model 
import os 

def process_image(img_path):
    img = image.load_img(img_path, target_size=(224, 224))
    img_array = image.img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    predictions = model.predict(img_array)
    
    cataract_status = "Present" if predictions[0][0] > 0.5 else "Absent"
    glaucoma_status = "Present" if predictions[1][0] > 0.5 else "Absent"
    dr_class = np.argmax(predictions[2][0])  #
    return {
        'cataract_status': cataract_status,
        'glaucoma_status': glaucoma_status,
        'dr_class': dr_class  
    }

def generate_gradcam(img_path, layer_name='top_conv'):
    def compute_gradcam(img_array, model, layer_name, class_index):
        grad_model = Model([model.inputs], [model.get_layer(layer_name).output, model.output[2]])

        with tf.GradientTape() as tape:
            conv_outputs, predictions = grad_model(img_array)
            loss = predictions[:, class_index]
        
        grads = tape.gradient(loss, conv_outputs)[0]
        conv_outputs = conv_outputs[0]
        weights = tf.reduce_mean(grads, axis=(0, 1))
        cam = np.dot(conv_outputs, weights.numpy())
        cam = cv2.resize(cam, (224, 224))
        cam = np.maximum(cam, 0)
        cam = cam / cam.max()
        return cam

    # Load and preprocess the image
    img = image.load_img(img_path, target_size=(224, 224))
    img_array = image.img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    # Get the DR class prediction
    dr_class = process_image(img_path)['dr_class']
    
    # Generate the Grad-CAM heatmap
    cam = compute_gradcam(img_array, model, layer_name, dr_class)
    
    # Apply the heatmap to the image
    heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
    img = cv2.imread(img_path)
    superimposed_img = cv2.addWeighted(cv2.resize(img, (224, 224)), 0.6, heatmap, 0.4, 0)

    # Save the Grad-CAM image
    gradcam_filename = f'gradcam_{os.path.basename(img_path)}'
    gradcam_path = os.path.join('/Users/priyankapalaniselvam/Downloads/RetinaNet/samples', gradcam_filename)  # Save to samples folder
    cv2.imwrite(gradcam_path, superimposed_img)
    # gradcam_path = f'./samples/gradcam_{img_path.split("/")[-1]}'
    # cv2.imwrite(gradcam_path, superimposed_img)
    return gradcam_path
