import tensorflow as tf
from tensorflow.keras.models import Model, load_model
import tensorflow as tf
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

def create_base_model(input_shape=(224, 224, 3)):
    base_model = tf.keras.applications.EfficientNetB0(
        include_top=False, 
        input_shape=input_shape,
        weights='imagenet'
    )
    base_model.trainable = True  
    return base_model

def add_task_specific_heads(base_model):
    x = base_model.output
    x = GlobalAveragePooling2D()(x)

    cataract_head = Dense(1, activation='sigmoid', name='cataract_output')(x)

    glaucoma_head = Dense(1, activation='sigmoid', name='glaucoma_output')(x)

    dr_head = Dense(5, activation='softmax', name='dr_output')(x)

    return Model(inputs=base_model.input, outputs=[cataract_head, glaucoma_head, dr_head])

def compile_model(model):
    model.compile(
        optimizer=Adam(learning_rate=1e-4),
        loss={
            'cataract_output': 'binary_crossentropy',    
            'glaucoma_output': 'binary_crossentropy',     
            'dr_output': 'categorical_crossentropy'       
        },
        metrics={
            'cataract_output': 'accuracy',
            'glaucoma_output': 'accuracy',
            'dr_output': 'accuracy'
        }
    )
    return model

def load_integrated_model(weights_path='/Users/priyankapalaniselvam/Downloads/RetinaNet/multi_task_model.weights.h5'):
    IMAGE_SIZE = (224, 224)
    BATCH_SIZE = 32
    input_shape=(*IMAGE_SIZE, 3)
    base_model = create_base_model(input_shape=(*IMAGE_SIZE, 3))  
    model = add_task_specific_heads(base_model)
    model = compile_model(model)
    model.load_weights('/Users/priyankapalaniselvam/Downloads/RetinaNet/multi_task_model_weights.h5')
    return model

model = load_integrated_model(weights_path='/Users/priyankapalaniselvam/Downloads/RetinaNet/multi_task_model.weights.h5')
