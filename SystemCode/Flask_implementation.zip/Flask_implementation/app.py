from flask import Flask, render_template, request, redirect, url_for, jsonify
import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
import os
import time
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.models import Sequential
from models.k_ga_model_high_return import k_ga_load_high_return_model
from models.k_ga_model_low_risk import k_ga_load_low_risk_model

app = Flask(__name__)

k_ga_STOCK_WEIGHTS_LOW_RISK = {
    "QQQ": 0.143926,
    "IVV": 0.130050,
    "VOO": 0.234148,
    "SPY": 0.003480,
    "ARKK": 0.104891,
    "ES3.SI": 0.001133,
    "VTI": 0.120862,
    "CEDU.SI": 0.176426,
    "S68.SI": 0.061940,
    "CJLU.SI": 0.023146
}

k_ga_STOCK_WEIGHTS_HIGH_RETURN = {
    'AMD': 0.0441,
    'GOOGL': 0.9914,
    'BABA': 0.9666,
    'AAPL': 0.0123,
    'J36.SI': 0.9511,
    'LVMUY': 0.9977,
    'ARKK': 0.9744,
    'AMZN': 0.9923,
    'MSFT': 0.9946,
    'QQQ': 0.9166
}

k_ga_model_high_return = k_ga_load_high_return_model()
k_ga_model_low_risk = k_ga_load_low_risk_model()

@app.route('/')
def home():
    return render_template('welcome.html')

@app.route('/get_started', methods=['GET'])
def get_started():
    return redirect(url_for('select_model'))

@app.route('/select_model', methods=['GET', 'POST'])
def select_model():
    if request.method == 'POST':
        portfolio_type = request.form.get('portfolio_type')
        if portfolio_type == 'Genetic Algorithm low_risk':
            model = k_ga_model_low_risk
            stock_weights = k_ga_STOCK_WEIGHTS_LOW_RISK
        elif portfolio_type == 'Genetic Algorithm high_return':
            model = k_ga_model_high_return
            stock_weights = k_ga_STOCK_WEIGHTS_HIGH_RETURN
        else:
            return jsonify({'error': 'Invalid portfolio type selected'})

        time.sleep(5) 

        return render_template('investment.html', portfolio_type=portfolio_type)

    return render_template('select_model.html')

@app.route('/investment', methods=['POST'])
def investment():
    investment_amount = float(request.form.get('investment_amount'))
    portfolio_type = request.form.get('portfolio_type')

    if portfolio_type == 'Genetic Algorithm low_risk':
        predictions = k_ga_model_low_risk.predict(np.random.rand(1, 60, 6))  
        stock_weights = k_ga_STOCK_WEIGHTS_LOW_RISK
    elif portfolio_type == 'Genetic Algorithm high_return':
        predictions = k_ga_model_high_return.predict(np.random.rand(1, 60, 6))  
        stock_weights = k_ga_STOCK_WEIGHTS_HIGH_RETURN
    else:
        return jsonify({'error': 'Invalid portfolio type selected'})

    # Calculate expected return for next 1 month and 3 months
    expected_return_1_month = np.mean(predictions[:30]) 
    expected_return_3_months = np.mean(predictions[:90]) 

    # Calculate expected earnings based on investment amount
    expected_earning_1_month = investment_amount * (1 + expected_return_1_month)
    expected_earning_3_months = investment_amount * (1 + expected_return_3_months)

    num_stocks = 10  
    investment_per_stock = {stock: investment_amount * weight for stock, weight in stock_weights.items()}

    return render_template('results.html', portfolio_type=portfolio_type, investment_amount=investment_amount,
                           expected_earning_1_month=expected_earning_1_month,
                           expected_earning_3_months=expected_earning_3_months,
                           investment_per_stock=investment_per_stock,
                           stock_weights=stock_weights)

if __name__ == '__main__':
    app.run(debug=True)