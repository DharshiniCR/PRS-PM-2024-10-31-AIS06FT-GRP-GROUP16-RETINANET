# models/__init__.py

from .k_ga_model_high_return import k_ga_load_high_return_model
from .k_ga_model_low_risk import k_ga_load_low_risk_model

__all__ = ['k_ga_load_high_return_model', 'k_ga_load_low_risk_model']
