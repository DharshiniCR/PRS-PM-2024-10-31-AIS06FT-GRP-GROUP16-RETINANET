from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.models import Sequential
import os

def k_ga_load_low_risk_model():
    model = Sequential()
    model.add(LSTM(units=50, return_sequences=True, input_shape=(60, 6)))  
    model.add(Dropout(0.2))
    model.add(LSTM(units=50, return_sequences=False))
    model.add(Dropout(0.2))
    model.add(Dense(units=25))
    model.add(Dense(units=1))  

    model.compile(optimizer='adam', loss='mean_squared_error')

    weights_path = os.path.join(os.path.dirname(__file__), 'model_low_risk_weights.weights.h5')
    model.load_weights(weights_path)

    return model
